# Turkish Experiment - Figures 3 & 4

library(foreign)
df3 = read.dta("means_medians_time3.dta")
df9 = read.dta("means_medians_time9.dta")

plot(meanwint0~time, data=df3[df3$pi==0,], type="l", ylim=c(4,8), xlim=c(0,2), xaxt="n", ylab="Votes", xlab="Time")
axis(1,at = seq(0, 2, by = 1))
lines(meanwint0~time, data=df3[df3$pi==1,], lty=2)

plot(medianwint0~time, data=df3[df3$pi==0,], type="l", ylim=c(4,9), xlim=c(0,2), xaxt="n", ylab="Votes", xlab="Time")
axis(1,at = seq(0, 2, by = 1))
lines(medianwint0~time, data=df3[df3$pi==1,], lty=2)

plot(meanwint09~time9, data=df9[df9$pi==0,], type="l", xlim=c(0,8), ylim=c(3,8), xaxt="n", ylab="Votes", xlab="Time")
axis(1,at = seq(0, 8, by = 1))
lines(meanwint09~time9, data=df9[df9$pi==1,], lty=2)

plot(medianwint09~time9, data=df9[df9$pi==0,], type="l", xlim=c(0,8), ylim=c(2,8), xaxt="n", ylab="Votes", xlab="Time")
axis(1,at = seq(0, 8, by = 1))
lines(medianwint09~time9, data=df9[df9$pi==1,], lty=2)


#========================================================================#
# Replication R code for:                                         
# Understanding People's Choice When they Have Two Votes        
#========================================================================#

#========================================================================#
# Loading Required Packages 
# May require installation  
#========================================================================#

library(MNP) #To run the Bayesian multinomial probits.
library(coda) #For mcmc functions. 
library(xtable) # To export results to LaTeX.
library(ggplot2) # For graphics.

#========================================================================#
# Loading Data File            
#========================================================================#

germany = read.csv('germany_2018.csv')

# Declaring dependent variables as factors and labelling:

germany$listvote = factor(germany$listvote, labels=c("CDU","SPD","Greens","FDP","Left"))
germany$localvote = factor(germany$localvote, labels=c("CDU","SPD","Greens","FDP","Left"))

#========================================================================#
# Estimating Multinomial Probits 
#========================================================================#
# Note: Variables prelocal1-5 and prelist1-5 are the pre-determined vote choices for contamination effects.
# Note: Computation time is about 24 hours.  Reduce number of draws if necessary.  Results will be about the same 
#       with 10,000+ draws.  The large model was used based on diagnostic statistics.
# For exact replication using the draws computed for the study, contact authors.

#========================================================================#
# List Vote Model 
#========================================================================#

# List Vote Model 1: Starting values at 0 (default) with 1,000,000 MCMC Draws

res1a = mnp(listvote ~ 1 + age + education + female + coalition + bavaria, 
                choiceX = list(CDU=cbind(rating1, leader1, idpart1, chances1, ratinglocal1, prelocal1),
                SPD=cbind(rating2, leader2, idpart2, chances2, ratinglocal2, prelocal2),
                Greens=cbind(rating3, leader3, idpart3, chances3, ratinglocal3, prelocal3),
                FDP=cbind(rating4, leader4, idpart4, chances4, ratinglocal4, prelocal4),
                Left=cbind(rating5, leader5, idpart5, chances5, ratinglocal5, prelocal5)),
                cXnames = c("party","leader","idpart","chances","ratinglocal","prelocal"), 
                data = germany, p.var=1, n.draws=1001000, burnin=1000, verbose=TRUE, trace=FALSE, p.scale=1)

# List Vote Model 2: Overdispersed starting values (1,-1,...) with 1,000,000 MCMC Draws

res1b = mnp(listvote ~ 1 + age + education + female + coalition + bavaria, 
                choiceX = list(CDU=cbind(rating1, leader1, idpart1, chances1, ratinglocal1, prelocal1),
                SPD=cbind(rating2, leader2, idpart2, chances2, ratinglocal2, prelocal2),
                Greens=cbind(rating3, leader3, idpart3, chances3, ratinglocal3, prelocal3),
                FDP=cbind(rating4, leader4, idpart4, chances4, ratinglocal4, prelocal4),
                Left=cbind(rating5, leader5, idpart5, chances5, ratinglocal5, prelocal5)),
                coef.start=c(1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1),
                cXnames = c("party","leader","idpart","chances","ratinglocal","prelocal"), 
                data = germany, p.var=1, n.draws=1001000, burnin=1000, verbose=TRUE, trace=FALSE, p.scale=1)

# List Vote Model 3: Overdispersed starting values (-1,1,...) with 1,000,000 MCMC Draws

res1c = mnp(listvote ~ 1 + age + education + female + coalition + bavaria, 
                choiceX = list(CDU=cbind(rating1, leader1, idpart1, chances1, ratinglocal1, prelocal1),
                SPD=cbind(rating2, leader2, idpart2, chances2, ratinglocal2, prelocal2),
                Greens=cbind(rating3, leader3, idpart3, chances3, ratinglocal3, prelocal3),
                FDP=cbind(rating4, leader4, idpart4, chances4, ratinglocal4, prelocal4),
                Left=cbind(rating5, leader5, idpart5, chances5, ratinglocal5, prelocal5)),
                coef.start=c(-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1),
                cXnames = c("party","leader","idpart","chances","ratinglocal","prelocal"), 
                data = germany, p.var=1, n.draws=1001000, burnin=1000, verbose=TRUE, trace=FALSE, p.scale=1)

#========================================================================#
# Candidate Vote Model 
#========================================================================#

# Candidate Vote Model 1: Starting values at 0 (default) with 1,000,000 MCMC Draws

res2a = mnp(localvote ~ 1 + age + education + female + coalition + bavaria, 
                choiceX = list(CDU=cbind(rating1, leader1, idpart1, chances1, ratinglocal1, prelist1),
                SPD=cbind(rating2, leader2, idpart2, chances2, ratinglocal2, prelist2),
                Greens=cbind(rating3, leader3, idpart3, chances3, ratinglocal3, prelist3),
                FDP=cbind(rating4, leader4, idpart4, chances4, ratinglocal4, prelist4),
                Left=cbind(rating5, leader5, idpart5, chances5, ratinglocal5, prelist5)),
                cXnames = c("party","leader","idpart","chances","ratinglocal","prelist"),
                data = germany, p.var=1, n.draws=1001000, burnin=1000, verbose=TRUE, trace=FALSE, p.scale=1)

# Candidate Vote Model 2: Overdispersed starting values (1,-1,...) with 1,000,000 MCMC Draws

res2b = mnp(localvote ~ 1 + age + education + female + coalition + bavaria, 
                choiceX = list(CDU=cbind(rating1, leader1, idpart1, chances1, ratinglocal1, prelist1),
                SPD=cbind(rating2, leader2, idpart2, chances2, ratinglocal2, prelist2),
                Greens=cbind(rating3, leader3, idpart3, chances3, ratinglocal3, prelist3),
                FDP=cbind(rating4, leader4, idpart4, chances4, ratinglocal4, prelist4),
                Left=cbind(rating5, leader5, idpart5, chances5, ratinglocal5, prelist5)),
                cXnames = c("party","leader","idpart","chances","ratinglocal","prelist"), 
                coef.start=c(-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1),
                data = germany, p.var=1, n.draws=1001000, burnin=1000, verbose=TRUE, trace=FALSE, p.scale=1)

# Candidate Vote Model 3: Overdispersed starting values (-1,1,...) with 1,000,000 MCMC Draws

res2c = mnp(localvote ~ 1 + age + education + female + coalition + bavaria, 
              choiceX = list(CDU=cbind(rating1, leader1, idpart1, chances1, ratinglocal1, prelist1),
              SPD=cbind(rating2, leader2, idpart2, chances2, ratinglocal2, prelist2),
              Greens=cbind(rating3, leader3, idpart3, chances3, ratinglocal3, prelist3),
              FDP=cbind(rating4, leader4, idpart4, chances4, ratinglocal4, prelist4),
              Left=cbind(rating5, leader5, idpart5, chances5, ratinglocal5, prelist5)),
              cXnames = c("party","leader","idpart","chances","ratinglocal","prelist"),
              coef.start=c(1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1), 
              data = germany,  p.var=1, n.draws=1001000, burnin=1000, verbose=TRUE, trace=FALSE, p.scale=1)

save.image('/w/research/vote/results/mainresults_6M.RData')


#========================================================================#
#         	Post-Estimation Analysis                   
#========================================================================#

#========================================================================#
# Combining the Draws from the Three Models (last 500,000 draws) 
#========================================================================#

#List Vote
combined1 = mcmc(rbind(res1a$param[500001:1000000,],
                        res1b$param[500001:1000000,],
                        res1c$param[500001:1000000,]))
#Candidate Vote
combined2 = mcmc(rbind(res2a$param[500001:1000000,],
                        res2b$param[500001:1000000,],
                        res2c$param[500001:1000000,]))

#========================================================================#
### Convergence Diagnostics: 
#========================================================================#

## Gelman-Rubin Tests (Table A1):

res.coda1 = mcmc.list(chain1=mcmc(res1a$param[500001:1000000,-31]),chain2=mcmc(res1b$param[500001:1000000,-31]),chain3=mcmc(res1c$param[500001:1000000,-31]))
res.coda2 = mcmc.list(chain1=mcmc(res2a$param[500001:1000000,-31]),chain2=mcmc(res2b$param[500001:1000000,-31]),chain3=mcmc(res2c$param[500001:1000000,-31]))

gelman1 = gelman.diag(res.coda1, transform=T)
gelman2 = gelman.diag(res.coda2, transform=T)

## Heidelberger and Welch's convergence diagnostic (Table A1):

heidel1 = heidel.diag(combined1)
heidel2 = heidel.diag(combined2)

#========================================================================#
# Summary of Main Results (Table 2)
#========================================================================#

# List vote model (3-digit precision):
results1 = matrix(nrow=40,ncol=4)
results1[,1] = colnames(res1a$param)
results1[31,2:4] = 1
for (i in c(1:30,32:40)){
  results1[i,2] = round(mean(combined1[,i]),digits=3)
  results1[i,3] = round(quantile(combined1[,i],probs=0.025),digits=3)
  results1[i,4] = round(quantile(combined1[,i],probs=0.975),digits=3)
}

# Candidate vote model (3-digit precision):
results2 = matrix(nrow=40,ncol=4)
results2[,1] = colnames(res2a$param)
results2[31,2:4] = 1
for (i in c(1:30,32:40)){
  results2[i,2] = round(mean(combined2[,i]),digits=3)
  results2[i,3] = round(quantile(combined2[,i],probs=0.025),digits=3)
  results2[i,4] = round(quantile(combined2[,i],probs=0.975),digits=3)
}

# Exporting models as LaTeX tables (uncomment to use):
# print(xtable(results1))
# print(xtable(results2))

#========================================================================#
# Computing Goodness-of-Fit Statistics:
#========================================================================#
### Percent correctly predicted:

## List vote model:
# Taking a random sample from the combined draws:
subsample1 = combined1[sample(nrow(combined1), 10000), ]
# Computing posterior predicted probabilities:
p1 = predict(res1a,newdata=germany,newdraw=subsample1,type="prob")
p1 = data.frame(p1["p"])
p1$pred = ""
for (i in 1:nrow(p1)){
  p1$pred[i] = which.max( p1[i,1:5] )
}
gof1 = data.frame(predicted=p1$pred,observed=germany$listvote)
ct1 = table(gof1$predicted,gof1$observed)
percent1 = sum(diag(ct1))/nrow(gof1)
round(percent1*100,digits=1) #Percent correctly predicted.

## Candidate vote model:
# Taking a random sample from the combined draws:
subsample2 = combined2[sample(nrow(combined2), 10000), ]
# Computing posterior predicted probabilities:
p2 = predict(res2a,newdata=germany,newdraw=subsample2,type="prob")
p2 = data.frame(p2["p"])
p2$pred = ""
for (i in 1:nrow(p2)){
  p2$pred[i] = which.max( p2[i,1:5] )
}
gof2 = data.frame(predicted=p2$pred,observed=germany$localvote)
ct2 = table(gof2$predicted,gof2$observed)
percent2 = sum(diag(ct2))/nrow(gof2)
round(percent2*100,digits=1) #Percent correctly predicted.

### Proportional reduction in errors (PRE):
e11 = nrow(gof1) - 1300   ## 1300 is the mode of the list vote
e12 = nrow(gof1) - sum(diag(ct1))
e21 = nrow(gof2) - 1423   ## 1423 is the mode of the candidate vote     
e22 = nrow(gof2) - sum(diag(ct2))
pre1 = (e11-e12)/e11
pre2 = (e21-e22)/e21
# Display PREs (mentioned in the text, Section "Findings")  
pre1*100 
pre2*100 

#=====================================================================================#
#                       Hypothesis Testing (Table 3)                       
# Computing Pr(β − α > 0|D)s and Pr(α - β > 0|D)s posterior probabilities  
#                         and Bayes Factors                                
#=====================================================================================#
## Note: Ratio of priors for Pr(H0) and Pr(H1) is set as .5/.5 = 1

# Matrix for results storage
B10 = matrix(nrow=9,ncol=4)

## Method 1:
B10[3,1] = sum(combined1[,25]>quantile(combined2[,25],probs=0.5))/nrow(combined1)
B10[4,1] = sum(combined1[,26]>quantile(combined2[,26],probs=0.5))/nrow(combined1)
B10[1,1] = sum(combined2[,28]>quantile(combined1[,28],probs=0.5))/nrow(combined2) 
B10[2,1] = sum(combined2[,29]>quantile(combined1[,29],probs=0.5))/nrow(combined2)  
B10[5,1] = sum(combined2[,30]>quantile(combined1[,30],probs=0.5))/nrow(combined2)
B10[6,1] = sum(combined1[,17]<quantile(combined2[,17],probs=0.5))/nrow(combined1)
B10[7,1] = sum(combined1[,18]<quantile(combined2[,18],probs=0.5))/nrow(combined1)
B10[8,1] = sum(combined1[,19]>quantile(combined2[,19],probs=0.5))/nrow(combined1)
B10[9,1] = sum(combined1[,20]<quantile(combined2[,20],probs=0.5))/nrow(combined1)

## Method 2:
B10[3,3] = sum((combined1[,25]-combined2[,25])>0)/nrow(combined1)
B10[4,3] = sum((combined1[,26]-combined2[,26])>0)/nrow(combined1)
B10[1,3] = sum((combined2[,28]-combined1[,28])>0)/nrow(combined2) 
B10[2,3] = sum((combined2[,29]-combined1[,29])>0)/nrow(combined2)   
B10[5,3] = sum((combined2[,30]-combined1[,30])>0)/nrow(combined2) 
B10[6,3] = sum((combined2[,17]-combined1[,17])>0)/nrow(combined1)
B10[7,3] = sum((combined2[,18]-combined1[,18])>0)/nrow(combined1)
B10[8,3] = sum((combined1[,19]-combined2[,19])>0)/nrow(combined1)
B10[9,3] = sum((combined2[,20]-combined1[,20])>0)/nrow(combined1)

# Computing 2 X log Bayes factors:
B10[1,2] = 2*log(B10[1,1]/(1-B10[1,1]))
B10[2,2] = 2*log(B10[2,1]/(1-B10[2,1]))
B10[3,2] = 2*log(B10[3,1]/(1-B10[3,1]))
B10[4,2] = 2*log(B10[4,1]/(1-B10[4,1]))
B10[5,2] = 2*log(B10[5,1]/(1-B10[5,1]))
B10[6,2] = 2*log(B10[6,1]/(1-B10[6,1]))
B10[7,2] = 2*log(B10[7,1]/(1-B10[7,1]))
B10[8,2] = 2*log(B10[8,1]/(1-B10[8,1]))
B10[9,2] = 2*log(B10[9,1]/(1-B10[9,1]))
B10[1,4] = 2*log(B10[1,3]/(1-B10[1,3]))
B10[2,4] = 2*log(B10[2,3]/(1-B10[2,3]))
B10[3,4] = 2*log(B10[3,3]/(1-B10[3,3]))
B10[4,4] = 2*log(B10[4,3]/(1-B10[4,3]))
B10[5,4] = 2*log(B10[5,3]/(1-B10[5,3]))
B10[6,4] = 2*log(B10[6,3]/(1-B10[6,3]))
B10[7,4] = 2*log(B10[7,3]/(1-B10[7,3]))
B10[8,4] = 2*log(B10[8,3]/(1-B10[8,3]))
B10[9,4] = 2*log(B10[9,3]/(1-B10[9,3]))

# Printing out the results, 3-digit precision:
round(B10, digits=3)

# Exporting results as a LaTeX table (uncomment following line):
# print(xtable(B10,digits=c(0,5,2,5,2)))

#========================================================================#
# Graphs of posterior distributions (Figure 1a-e):
#========================================================================#

library(ggplot2)

df1 = data.frame(combined1[,25],combined2[,25],
                  combined1[,26],combined2[,26],
                  combined2[,28],combined1[,28],
                  combined2[,29],combined1[,29],
                  combined2[,30],combined1[,30])
names(df1) =c("partyl","partyc","leaderl","leaderc",
				"chancesc","chancesl","localratgsc","localratgsl",
				"contaminLC","contaminCL")

#pdf('fig1a.pdf', width=7, height=5, paper='special')
tiff('fig1a.tif', width=7, height=5, units='in', 
     compression= 'lzw', res=600)
fig1a = ggplot(df1) + 
  theme_bw() + 
  geom_histogram(aes(x=chancesc, fill='Candidate'),  alpha=1, bins=100) +
  geom_histogram(aes(x=chancesl, fill='List'),  alpha=0.65, bins=100) +
  xlab("Parameter Value") +
  ylab("Frequency") + 
  #geom_vline(xintercept=0, lty=2) +
  scale_fill_manual("", values =c('gray70','black'), labels=c("Candidate Vote", "List Vote")) +
  theme(legend.position = c(.02, .98),
        legend.justification = c(.02, .98),
        legend.background = element_rect(color = "transparent", 
                                         fill = "transparent"))
fig1a
dev.off()

#pdf('fig1b.pdf', width=7, height=5, paper='special')
tiff('fig1b.tif', width=7, height=5, units='in', 
     compression= 'lzw', res=600)
fig1b = ggplot(df1) + 
  theme_bw() + 
  geom_histogram(aes(x=localratgsc, fill='Candidate'),  alpha=1, bins=100) +
  geom_histogram(aes(x=localratgsl, fill='List'),  alpha=0.65, bins=100) +
  xlab("Parameter Value") +
  ylab("Frequency") + 
  #geom_vline(xintercept=0, lty=2) +
  scale_fill_manual("", values =c('gray70','black'), labels=c("Candidate Vote", "List Vote")) +
  theme(legend.position = c(.02, .98),
        legend.justification = c(.02, .98),
        legend.background = element_rect(color = "transparent", 
                                         fill = "transparent"))
fig1b
dev.off()

#pdf('fig1c.pdf', width=7, height=5, paper='special')
tiff('fig1c.tif', width=7, height=5, units='in', 
     compression= 'lzw', res=600)
fig1c = ggplot(df1) + 
  theme_bw() + 
  geom_histogram(aes(x=partyc, fill='Candidate'),  alpha=1, bins=100) +
  geom_histogram(aes(x=partyl, fill='List'),  alpha=0.65, bins=100) +
  xlab("Parameter Value") +
  ylab("Frequency") + 
  #geom_vline(xintercept=0, lty=2) +
  scale_fill_manual("", values =c('gray70','black'), labels=c("Candidate Vote", "List Vote")) +
  theme(legend.position = c(.02, .98),
        legend.justification = c(.02, .98),
        legend.background = element_rect(color = "transparent", 
                                         fill = "transparent"))
fig1c
dev.off()

#pdf('fig1d.pdf', width=7, height=5, paper='special')
tiff('fig1d.tif', width=7, height=5, units='in', 
     compression= 'lzw', res=600)
fig1d = ggplot(df1) + 
  theme_bw() + 
  geom_histogram(aes(x=leaderc, fill='Candidate'),  alpha=1, bins=100) +
  geom_histogram(aes(x=leaderl, fill='List'),  alpha=0.65, bins=100) +
  xlab("Parameter Value") +
  ylab("Frequency") + 
  #geom_vline(xintercept=0, lty=2) +
  scale_fill_manual("", values =c('gray70','black'), labels=c("Candidate Vote", "List Vote")) +
  theme(legend.position = c(.02, .98),
        legend.justification = c(.02, .98),
        legend.background = element_rect(color = "transparent", 
                                         fill = "transparent"))
fig1d
dev.off()

tiff('fig1e.tif', width=7, height=5, units='in', 
     compression= 'lzw', res=600)
#pdf('fig1e.pdf', width=7, height=5, paper='special')
fig1e = ggplot(df1) + 
  theme_bw() + 
  geom_histogram(aes(x=contaminLC, fill='Candidate'),  alpha=1, bins=100) +
  geom_histogram(aes(x=contaminCL, fill='List'),  alpha=0.65, bins=100) +
  xlab("Parameter Value") +
  ylab("Frequency") + 
  #geom_vline(xintercept=0, lty=2) +
  scale_fill_manual("", values =c('gray70','black'), labels=c("List Vote -> Candidate Vote", "Candidate Vote -> List Vote")) +
  theme(legend.position = c(.02, .98),
        legend.justification = c(.02, .98),
        legend.background = element_rect(color = "transparent", 
                                         fill = "transparent"))
fig1e
dev.off()

# Writing the figures data to file.
# write.table(df1,"figuresdata.csv",sep=",",row.names=F,col.names=T)
